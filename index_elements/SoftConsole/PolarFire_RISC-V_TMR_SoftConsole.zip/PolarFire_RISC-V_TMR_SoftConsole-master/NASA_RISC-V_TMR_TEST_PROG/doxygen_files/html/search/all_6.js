var searchData=
[
  ['fifo_5fdepth_18',['fifo_depth',['../structspi__instance.html#a7298e290ba7b4463febf28c2960db842',1,'spi_instance']]],
  ['fram_5fdev_19',['fram_dev',['../spi__test__prog_8c.html#a02bd3a1d8e294a8f64c769178ec07eea',1,'fram_dev():&#160;spi_test_prog.c'],['../spi__test__prog_8h.html#a02bd3a1d8e294a8f64c769178ec07eea',1,'fram_dev():&#160;spi_test_prog.c']]],
  ['frame_5frx_5fhandler_20',['frame_rx_handler',['../structspi__instance.html#a9a5926bb4e7b34ba50b0c96e07c6142f',1,'spi_instance']]]
];
