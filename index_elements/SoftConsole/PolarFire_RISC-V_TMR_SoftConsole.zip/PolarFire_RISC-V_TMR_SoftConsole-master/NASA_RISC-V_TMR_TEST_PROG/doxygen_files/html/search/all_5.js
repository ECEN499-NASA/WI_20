var searchData=
[
  ['enter_13',['ENTER',['../i2c__test__routine_8h.html#af4bced5cf8ed55746d4b5d34f9a0fe39',1,'i2c_test_routine.h']]],
  ['external_5f5_5firqhandler_14',['External_5_IRQHandler',['../i2c__test__routine_8c.html#a0c16005be8e03b4494a076d540bfec0d',1,'i2c_test_routine.c']]],
  ['external_5f6_5firqhandler_15',['External_6_IRQHandler',['../i2c__test__routine_8c.html#a2ca1630bce1c7e20f437fe4647c8695f',1,'i2c_test_routine.c']]],
  ['external_5fspi_5f0_16',['external_spi_0',['../spi__test__prog_8c.html#a277eb22a369721f017cd65d93034d8b7',1,'external_spi_0():&#160;spi_test_prog.c'],['../spi__test__prog_8h.html#a277eb22a369721f017cd65d93034d8b7',1,'external_spi_0():&#160;spi_test_prog.c']]],
  ['external_5fspi_5f1_17',['external_spi_1',['../spi__test__prog_8c.html#a623ebc73879144145e467950be650deb',1,'external_spi_1():&#160;spi_test_prog.c'],['../spi__test__prog_8h.html#a623ebc73879144145e467950be650deb',1,'external_spi_1():&#160;spi_test_prog.c']]]
];
