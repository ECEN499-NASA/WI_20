var searchData=
[
  ['base_5faddr_171',['base_addr',['../structspi__instance.html#a33fadb8ca646c00e54609a7858be737b',1,'spi_instance']]],
  ['block_5frx_5fhandler_172',['block_rx_handler',['../structspi__instance.html#af64bb177590ae54be4fe53992961049c',1,'spi_instance']]]
];
