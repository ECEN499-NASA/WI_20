var searchData=
[
  ['spi_5fdev_110',['spi_dev',['../structspi__dev.html',1,'']]],
  ['spi_5finstance_111',['spi_instance',['../structspi__instance.html',1,'']]]
];
