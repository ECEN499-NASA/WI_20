var searchData=
[
  ['external_5fspi_5f0_174',['external_spi_0',['../spi__test__prog_8c.html#a277eb22a369721f017cd65d93034d8b7',1,'external_spi_0():&#160;spi_test_prog.c'],['../spi__test__prog_8h.html#a277eb22a369721f017cd65d93034d8b7',1,'external_spi_0():&#160;spi_test_prog.c']]],
  ['external_5fspi_5f1_175',['external_spi_1',['../spi__test__prog_8c.html#a623ebc73879144145e467950be650deb',1,'external_spi_1():&#160;spi_test_prog.c'],['../spi__test__prog_8h.html#a623ebc73879144145e467950be650deb',1,'external_spi_1():&#160;spi_test_prog.c']]]
];
