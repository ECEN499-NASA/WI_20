var searchData=
[
  ['int_5fto_5fhex_5fstring_133',['int_to_hex_string',['../user__handler_8c.html#a77f375f90c3968d56d1bd03b0a754c30',1,'int_to_hex_string(uint32_t num, char hex_string[12]):&#160;user_handler.c'],['../user__handler_8h.html#a77f375f90c3968d56d1bd03b0a754c30',1,'int_to_hex_string(uint32_t num, char hex_string[12]):&#160;user_handler.c']]],
  ['int_5fto_5fsingle_5fbyte_5fstring_134',['int_to_single_byte_string',['../user__handler_8c.html#a2209b2abeaa2ec57db9f82a4d89b4e07',1,'int_to_single_byte_string(uint8_t num, char hex_string[5]):&#160;user_handler.c'],['../user__handler_8h.html#a2209b2abeaa2ec57db9f82a4d89b4e07',1,'int_to_single_byte_string(uint8_t num, char hex_string[5]):&#160;user_handler.c']]]
];
