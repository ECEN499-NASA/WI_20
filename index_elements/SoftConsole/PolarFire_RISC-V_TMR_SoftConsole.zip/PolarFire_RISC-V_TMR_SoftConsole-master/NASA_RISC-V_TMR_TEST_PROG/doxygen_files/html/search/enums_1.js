var searchData=
[
  ['spi_5fdevice_5fid_200',['SPI_DEVICE_ID',['../spi__test__prog_8h.html#a87f243d506ce62a8a002b5976d3a4844',1,'spi_test_prog.h']]],
  ['spi_5ftest_5fsel_201',['SPI_TEST_SEL',['../spi__test__prog_8h.html#ad2469a4b04e341d27cfc8c1f6b718c79',1,'spi_test_prog.h']]]
];
